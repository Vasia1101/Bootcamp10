import React from 'react';

const About = () => <h1>Public about page</h1>;

export default About;
