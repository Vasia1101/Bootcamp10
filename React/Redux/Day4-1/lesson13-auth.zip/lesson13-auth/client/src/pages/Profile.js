import React from 'react';

const Profile = () => <h1>Protected profile page</h1>;

export default Profile;
