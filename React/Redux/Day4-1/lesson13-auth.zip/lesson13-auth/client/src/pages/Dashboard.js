import React from 'react';

const Dashboard = () => <h1>Protected dashboard page</h1>;

export default Dashboard;
