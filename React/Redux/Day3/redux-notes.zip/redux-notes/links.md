https://jaysoo.ca/2016/02/28/organizing-redux-application/
https://marmelab.com/blog/2015/12/17/react-directory-structure.html
http://engineering.kapost.com/2016/01/organizing-large-react-applications/
https://medium.com/@msandin/strategies-for-organizing-code-2c9d690b6f33
