const ADD = 'notes/ADD';
const DELETE = 'notes/DELETE';
const TOGGLE_COMPLETED = 'notes/TOGGLE_COMPLETED';
const CHANGE_FILTER = 'notes/CHANGE_FILTER';

export default { ADD, DELETE, TOGGLE_COMPLETED, CHANGE_FILTER };
